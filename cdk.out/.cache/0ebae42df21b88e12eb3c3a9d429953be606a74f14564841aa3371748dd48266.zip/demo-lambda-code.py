def lambda_handler(event, context):
    print("hello from demo lambda")